//Engine.java (Common Interface)
package com.nt.sbeans;

public interface Engine {
    public  void start();
    public   void stop();
}
