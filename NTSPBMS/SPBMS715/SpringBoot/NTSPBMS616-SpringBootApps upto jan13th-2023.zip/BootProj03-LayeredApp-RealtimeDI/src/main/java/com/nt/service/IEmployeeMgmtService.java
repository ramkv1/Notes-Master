//IEmployeeMgmtService.java
package com.nt.service;

import com.nt.model.Employee;

public interface IEmployeeMgmtService {
   public  String  registerEmployee(Employee emp)throws Exception;
}
