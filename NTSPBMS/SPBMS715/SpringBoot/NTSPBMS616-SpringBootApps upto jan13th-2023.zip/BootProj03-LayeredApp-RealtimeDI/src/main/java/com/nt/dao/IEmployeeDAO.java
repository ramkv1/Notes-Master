//DAOInterface
package com.nt.dao;

import com.nt.model.Employee;

public interface IEmployeeDAO {
     public   int  insert(Employee emp)throws Exception;	
}
